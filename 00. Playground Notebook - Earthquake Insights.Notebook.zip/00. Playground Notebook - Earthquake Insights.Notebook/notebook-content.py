# Fabric notebook source

# METADATA ********************

# META {
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "3626e5fe-81ce-49ee-87cf-bc2b6142ebb0",
# META       "default_lakehouse_name": "lh_Earthquakes",
# META       "default_lakehouse_workspace_id": "68ac3c56-efbc-4939-98f9-9efc8d1fd721"
# META     }
# META   }
# META }

# MARKDOWN ********************

# Earthquake Insights - Playground
# https://www.youtube.com/watch?v=Av44Nrhl05s&list=PL6pAXQQpiH-kNkBspRcYvG6njEBuXpQG_&index=3

# MARKDOWN ********************

# PREPARATION

# CELL ********************

url = "https://earthquake.usgs.gov/fdsnws/event/1/query?format=geojson&starttime=2014-01-01&endtime=2014-01-02"
print(url)

# CELL ********************

import requests

# CELL ********************

requests.get(url)

# CELL ********************

requests.get(url).status_code

# CELL ********************

response = requests.get(url)

# CELL ********************

response.json()

# CELL ********************

response.json()['features']

# MARKDOWN ********************

# Unix Timestamp Convertor: https://www.unixtimestamp.com/
# JSON formattter: https://jsonformatter.org/json-parser

# CELL ********************

# MAGIC %%sql
# MAGIC 
# MAGIC DESCRIBE HISTORY lh_Earthquakes.earthquake_events_silver;
