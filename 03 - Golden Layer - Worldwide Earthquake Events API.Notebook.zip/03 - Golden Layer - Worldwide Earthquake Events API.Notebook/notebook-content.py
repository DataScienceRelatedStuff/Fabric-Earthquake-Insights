# Fabric notebook source

# METADATA ********************

# META {
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "3626e5fe-81ce-49ee-87cf-bc2b6142ebb0",
# META       "default_lakehouse_name": "lh_Earthquakes",
# META       "default_lakehouse_workspace_id": "68ac3c56-efbc-4939-98f9-9efc8d1fd721"
# META     },
# META     "environment": {
# META       "environmentId": "7ea5e339-02ff-4511-acd9-5c5e3df63c98",
# META       "workspaceId": "68ac3c56-efbc-4939-98f9-9efc8d1fd721"
# META     }
# META   }
# META }

# MARKDOWN ********************

# # Golden Layer - Worldwide Earthquake Events API

# CELL ********************

from pyspark.sql.functions import when, col, udf
from pyspark.sql.types import StringType
# ensure the below library is installed on your fabric environment
# https://pypi.org/project/reverse_geocoder/
import reverse_geocoder as rg

# CELL ********************

#start_date = '2023-12-31'
#print(start_date)

# CELL ********************

df = spark.read.table("earthquake_events_silver").filter(col('time') > start_date)

# CELL ********************

"""
coordinates = (51, 5.5), (51.5214588,-0.1729636),(9.936033, 76.259952),(37.38605,-122.08385)
coordinates = (-123.99866666666667, 45.1505)

rg.search(coordinates)[0]
rg.search(coordinates)[0].get('cc')
#'cc' = ISO-code for countries
"""

# CELL ********************

#display(df)

# CELL ********************

def get_country_code(lat, lon):
    """
    Retrieve the country code for a given latitude and longitude.

    Parameters:
    lat (float or str): Latitude of the location.
    lon (float or str): Longitude of the location.

    Returns:
    str: Country code of the location, retrieved using the reverse geocoding API.

    Example:
    >>> get_country_details(48.8588443, 2.2943506)
    'FR'
    """
    coordinates = (float(lat), float(lon))
    return rg.search(coordinates)[0].get('cc')

# CELL ********************

# registering the udfs so they can be used on spark dataframes
get_country_code_udf = udf(get_country_code, StringType())

# CELL ********************

# adding country_code and city attributes
df_with_location = \
                df.\
                    withColumn("country_code", get_country_code_udf(col("latitude"), col("longitude")))

# CELL ********************

#display(df_with_location)

# CELL ********************

# adding significance classification
df_with_location_sig_class = \
                            df_with_location.\
                                withColumn('sig_class', 
                                            when(col("sig") < 100, "Low").\
                                            when((col("sig") >= 100) & (col("sig") < 500), "Moderate").\
                                            otherwise("High")
                                            )

# CELL ********************

#display(df_with_location_sig_class)

# CELL ********************

# appending the data to the gold table
df_with_location_sig_class.write.mode('append').saveAsTable('earthquake_events_gold')
