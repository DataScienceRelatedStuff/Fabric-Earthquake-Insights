# Fabric notebook source

# METADATA ********************

# META {
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "3626e5fe-81ce-49ee-87cf-bc2b6142ebb0",
# META       "default_lakehouse_name": "lh_Earthquakes",
# META       "default_lakehouse_workspace_id": "68ac3c56-efbc-4939-98f9-9efc8d1fd721"
# META     }
# META   }
# META }

# MARKDOWN ********************

# # Silver Layer - Worldwide Earthquake Events API

# CELL ********************

from pyspark.sql.functions import col
from pyspark.sql.types import TimestampType

# CELL ********************

#from datetime import date, timedelta

#start_date = date.today() - timedelta(7)
#print(start_date)

# CELL ********************

# df now is a Spark DataFrame containing JSON data
df = spark.read.option("multiline", "true").json(f"Files/{start_date}_earthquake_data.json")

# CELL ********************

#display(df)

# CELL ********************

#display(df.select('geometry.coordinates'))

# CELL ********************

#display(df.select(col('geometry.coordinates').getItem(0)))

# CELL ********************

#display(df.select(col('geometry.coordinates').getItem(1)))

# CELL ********************

#display(df.select(col('properties.title')))

# CELL ********************

#display(df.select(col('properties.type')))

# CELL ********************

#display(df.select(col('properties.tsunami')))

# CELL ********************

# Reshape earthquake data by extracting and renaming key attributes for further analysis.
df = \
df.\
    select(
        'id',
        col('geometry.coordinates').getItem(0).alias('longitude'),
        col('geometry.coordinates').getItem(1).alias('latitude'),
        col('geometry.coordinates').getItem(2).alias('elevation'),
        col('properties.title').alias('title'),
        col('properties.place').alias('place_description'),
        col('properties.sig').alias('sig'),
        col('properties.mag').alias('mag'),
        col('properties.magType').alias('magType'),
        col('properties.time').alias('time'),
        col('properties.updated').alias('updated')

        ,
        col('properties.url').alias('url'),
        col('properties.status').alias('status'),
        col('properties.tsunami').alias('tsunami'),
        col('properties.type').alias('type')

        )

# CELL ********************

#display(df)

# CELL ********************

# Convert 'time' and 'updated' columns from milliseconds to timestamp format for clearer datetime representation.
df = df.\
    withColumn('time', col('time')/1000).\
    withColumn('updated', col('updated')/1000).\
    withColumn('time', col('time').cast(TimestampType())).\
    withColumn('updated', col('updated').cast(TimestampType()))

# CELL ********************

#display(df)

# CELL ********************

# appending the data to the gold table
df.write.mode('append').saveAsTable('earthquake_events_silver')
